#include<opencv2/core/core.hpp>
#include<opencv2/opencv.hpp>
#include<opencv2/imgproc/imgproc.hpp>
#include<iostream>
#include<fstream>
#include<ml.h>
#include<string>
#include "feature.h"
using namespace cv;
using namespace std;
using namespace ml;
//vector<Mat> horizontalProjectionMat(Mat srcImg)//ˮƽͶӰ
//{
//	Mat binImg;
//	blur(srcImg, binImg, Size(3, 3));
//	threshold(binImg, binImg, 0, 255, CV_THRESH_OTSU);
//	int perPixelValue = 0;//ÿ�����ص�ֵ
//	int width = srcImg.cols;
//	int height = srcImg.rows;
//	int* projectValArry = new int[height];//����һ������ÿ�а�ɫ���ظ���������
//	memset(projectValArry, 0, height * 4);//��ʼ������
//	for (int col = 0; col < height; col++)//����ÿ�����ص�
//	{
//		for (int row = 0; row < width; row++)
//		{
//			perPixelValue = binImg.at<uchar>(col, row);
//			if (perPixelValue == 0)//����ǰ׵׺���
//			{
//				projectValArry[col]++;
//			}
//		}
//	}
//	Mat horizontalProjectionMat(height, width, CV_8UC1);//��������
//	for (int i = 0; i < height; i++)
//	{
//		for (int j = 0; j < width; j++)
//		{
//			perPixelValue = 255;
//			horizontalProjectionMat.at<uchar>(i, j) = perPixelValue;//���ñ���Ϊ��ɫ
//		}
//	}
//	for (int i = 0; i < height; i++)//ˮƽֱ��ͼ
//	{
//		for (int j = 0; j < projectValArry[i]; j++)
//		{
//			perPixelValue = 0;
//			horizontalProjectionMat.at<uchar>(i, width - 1 - j) = perPixelValue;//����ֱ��ͼΪ��ɫ
//		}
//	}
//	vector<Mat> roiList;//���ڴ���ָ������ÿ���ַ�
//	int startIndex = 0;//��¼�����ַ���������
//	int endIndex = 0;//��¼����հ����������
//	bool inBlock = false;//�Ƿ���������ַ�����
//	for (int i = 0; i <srcImg.rows; i++)
//	{
//		if (!inBlock && projectValArry[i] != 0)//�����ַ���
//		{
//			inBlock = true;
//			startIndex = i;
//		}
//		else if (inBlock && projectValArry[i] == 0)//����հ���
//		{
//			endIndex = i;
//			inBlock = false;
//			Mat roiImg = srcImg(Range(startIndex, endIndex + 1), Range(0, srcImg.cols));//��ԭͼ�н�ȡ��ͼ�������
//			roiList.push_back(roiImg);
//		}
//	}
//	delete[] projectValArry;
//	return roiList;
//}


vector<Mat> verticalProjectionMat(Mat srcImg,Mat binImg)//��ֱͶӰ
{
		
	int perPixelValue;//ÿ�����ص�ֵ
	int width = srcImg.cols;
	int height = srcImg.rows;
	int* projectValArry = new int[width];//�������ڴ���ÿ�а�ɫ���ظ���������
	memset(projectValArry, 0, width * 4);//��ʼ������
	for (int col = 0; col < width; col++)
	{
		for (int row = 0; row < height; row++)
		{
			perPixelValue = binImg.at<uchar>(row, col);
			if (perPixelValue == 255)//����ǰ׵׺���//0
			{
				projectValArry[col]++;
			}
		}
	}

	Mat verticalProjectionMat(height, width, CV_8UC1);//��ֱͶӰ�Ļ���
	for (int i = 0; i < height; i++)
	{
		for (int j = 0; j < width; j++)
		{
			perPixelValue = 0;  //��������Ϊ��ɫ//255
			verticalProjectionMat.at<uchar>(i, j) = perPixelValue;
		}
	}
	for (int i = 0; i < width; i++)//��ֱͶӰֱ��ͼ
	{
		for (int j = 0; j < projectValArry[i]; j++)
		{
			perPixelValue = 255;  //ֱ��ͼ����Ϊ��ɫ  //0
			verticalProjectionMat.at<uchar>(height - 1 - j, i) = perPixelValue;
		}
	}
	imshow("��ֱͶӰ", verticalProjectionMat);
	cvWaitKey(0);

	vector<Mat> roiList;//���ڴ���ָ������ÿ���ַ�
	int startIndex = 0;//��¼�����ַ���������
	int endIndex = 0;//��¼����հ����������
	bool inBlock = false;//�Ƿ���������ַ�����
	for (int i = 0; i < srcImg.cols; i++)//cols=width
	{
		if (!inBlock && projectValArry[i] != 0)//�����ַ���
		{
			inBlock = true;
			startIndex = i;
		}
		else if (projectValArry[i] == 0 && inBlock)//����հ���
		{
			endIndex = i;
			inBlock = false;
			Mat roiImg = srcImg(Range(0, srcImg.rows), Range(startIndex, endIndex + 1));
			roiList.push_back(roiImg);
		}
	}
	delete[] projectValArry;
	return roiList;
}

bool verifyCharSizes(Mat r) 
{
	// Char sizes 45x90
	float aspect = 45.0f / 90.0f;
	float charAspect = (float)r.cols / (float)r.rows;
	float error = 0.65f;//0.7//0.47//0.49//0.65
	float minHeight = 10.f;
	float maxHeight = 35.f;
	// We have a different aspect ratio for number 1, and it can be ~0.2
	float minAspect = 0.05f;
	float maxAspect = aspect + aspect * error;
	// area of pixels
	int area = cv::countNonZero(r);
	// bb area
	int bbArea = r.cols * r.rows;
	//% of pixel in area
	int percPixels = area / bbArea;

	/*if (percPixels <= 1 && charAspect > minAspect && charAspect < maxAspect &&
		r.rows >= minHeight && r.rows < maxHeight)
		return true;*/
	if (charAspect > minAspect && charAspect < maxAspect&&bbArea>40&& area>35&& r.rows >=16)//40,35,16//
		return true;
	else
		return false;
}

Mat preprocessChar(Mat in) 
{
	// Remap image
	int h = in.rows;
	int w = in.cols;

	int charSize = 20;

	Mat transformMat = Mat::eye(2, 3, CV_32F);
	int m = max(w, h);
	transformMat.at<float>(0, 2) = float(m / 2 - w / 2);
	transformMat.at<float>(1, 2) = float(m / 2 - h / 2);

	Mat warpImage(m, m, in.type());
	warpAffine(in, warpImage, transformMat, warpImage.size(), INTER_LINEAR,
		BORDER_CONSTANT, Scalar(0));

	Mat out;
	resize(warpImage, out, Size(charSize, charSize));

	return out;
}
//void main()
//{
//	string imgname;
//	string savename;
//	string file_name;
//	ifstream fin("C:/Users/root/Desktop/new/Plates/plates.txt");	
//	Mat src;	
//	while (getline(fin, imgname))
//		{		
//		file_name = imgname;
//		file_name.erase(file_name.end() - 4, file_name.end());
//		imgname = "C:/Users/root/Desktop/new/Plates/" + imgname;
//		
//			src = imread(imgname);//	"C:/Users/root/Desktop/new/Plates/A02_QW3691_0.jpg"
//			//Mat img_src = src(Rect_<double>(src.size().width*0.028, src.size().height*0.067, src.size().width*0.95, src.size().height*0.86));
//			Mat gray;		
//			cvtColor(src, gray, CV_BGR2GRAY);
//			Mat img_threshold;				
//			threshold(gray, img_threshold, 0, 255, CV_THRESH_BINARY + CV_THRESH_OTSU);// //187						
//			//imshow("threshold", img_threshold);
//			
//			vector<vector<Point>> con;
//			findContours(img_threshold,con, RETR_EXTERNAL, CHAIN_APPROX_NONE);
//			
//			vector<vector<Point>>::iterator itc = con.begin();
//			vector<Rect> rects;
//			while (itc != con.end())
//			{
//				Rect mr = boundingRect(Mat(*itc));
//				Mat auxROI(img_threshold,mr);			
//				if (verifyCharSizes(auxROI))
//					rects.push_back(mr);							
//				++itc;
//			}	
//		
//			if (rects.size() == 7)//�õ�7���ַ�����������
//			{
//				for (int i = 0; i < 6; i++)
//				{
//					for (int j = 0; j < 6 - i; j++)
//					{
//						if (rects[j].x > rects[j + 1].x)
//							swap(rects[j], rects[j+1]);
//					}
//				}
//				rects[0].y = rects[1].y;
//				rects[0].x = rects[0].x*0.68;
//				rects[0].height = rects[1].height;
//				rects[0].width = rects[0].width*1.5;
//			}
//			if (rects.size() == 8)//�õ�8���ַ�����������
//			{
//				for (int i = 0; i < 7; i++)
//				{
//					for (int j = 0; j < 7 - i; j++)
//					{
//						if (rects[j].x > rects[j + 1].x)
//							swap(rects[j], rects[j + 1]);
//					}
//				}
//				auto it = rects.begin();
//				if (rects[0].width > rects[7].width&&(abs(rects[7].y- rects[6].y)>3|| abs(rects[7].height - rects[6].height)>3))
//				{
//					it = rects.end()-1;
//					rects.erase(it);
//				}
//				if (rects[0].width + 5 < rects[1].width)
//				{
//					it = rects.begin();
//					rects.erase(it);
//				}
//				if (rects[0].width > 20)
//				{
//					it = rects.begin();
//					rects.erase(it);
//				}
//				rects[0].y = rects[1].y;
//				rects[0].x = rects[0].x*0.68;
//				rects[0].height = rects[1].height;
//				rects[0].width = rects[0].width*1.5;
//			}
//			if (rects.size() == 9)//�õ�9���ַ�����������
//			{
//				for (int i = 0; i < 8; i++)
//				{
//					for (int j = 0; j < 8 - i; j++)
//					{
//						if (rects[j].x > rects[j + 1].x)
//							swap(rects[j], rects[j + 1]);
//					}
//				}
//				auto it = rects.begin();
//				rects.erase(it);
//				it = rects.end()-1;
//				rects.erase(it);
//				rects[0].y = rects[1].y;
//				rects[0].x = rects[0].x*0.68;
//				rects[0].height = rects[1].height;
//				rects[0].width = rects[0].width*1.5;
//			}			
//			/*for (int i = 0; i < rects.size(); i++)
//			{
//				rectangle(src, rects[i], Scalar(0, 0, 255));
//			}
//			imshow("dst", src);
//			waitKey(0);*/
//			/*if (rects.size() != 7)
//			{
//				cout<< file_name << endl;
//			}*/
//			for (int i = 0; i < 7; i++)
//			{
//				Mat ch(img_threshold, rects[i]);
//				ch=preprocessChar(ch);
//				savename="C:/Users/root/Desktop/new/char/"+ file_name + "_" + to_string(i) + ".jpg";
//				imwrite(savename,ch);
//			}
//		}
//		waitKey(0);	
//}

const char strCharacters[] = { '0','1','2','3','4','5','6','7','8','9','A','B','C' };
//,'D','E','F','G','H','J','K','L','M','N',
//'P','Q','R','S','T','U','V','W','X','Y','Z'};
const int numCharacters = 13;
const int numFilesChars[] = {12,11,20,18,3,49,57,11,73,67,36,5,10};
void main()
{	
	Mat classes;
	Mat trainingData;
	Mat src;
	vector<int> trainingLabels;
	string imgname;
	string savename;
	string file_name;
	string file_path;
	for (int i = 0; i < numCharacters; i++)
	{
		if (i == 0)
		{
			file_path="C:/Users/root/Desktop/new/char/0/";
			file_name = "C:/Users/root/Desktop/new/char/0/0.txt";
		}
		if (i == 1)
		{
			file_path = "C:/Users/root/Desktop/new/char/1/";
			file_name = "C:/Users/root/Desktop/new/char/1/1.txt";
		}
		if (i == 2)
		{
			file_path = "C:/Users/root/Desktop/new/char/2/";
			file_name = "C:/Users/root/Desktop/new/char/2/2.txt";
		}
		if (i == 3)
		{
			file_path = "C:/Users/root/Desktop/new/char/3/";
			file_name = "C:/Users/root/Desktop/new/char/3/3.txt";
		}
		if (i == 4)
		{
			file_path = "C:/Users/root/Desktop/new/char/4/";
			file_name = "C:/Users/root/Desktop/new/char/4/4.txt";
		}
		if (i == 5)
		{
			file_path = "C:/Users/root/Desktop/new/char/5/";
			file_name = "C:/Users/root/Desktop/new/char/5/5.txt";
		}
		if (i == 6)
		{
			file_path = "C:/Users/root/Desktop/new/char/6/";
			file_name = "C:/Users/root/Desktop/new/char/6/6.txt";
		}
		if (i == 7)
		{
			file_path = "C:/Users/root/Desktop/new/char/7/";
			file_name = "C:/Users/root/Desktop/new/char/7/7.txt";
		}
		if (i == 8)
		{
			file_path = "C:/Users/root/Desktop/new/char/8/";
			file_name = "C:/Users/root/Desktop/new/char/8/8.txt";
		}
		if (i == 9)
		{
			file_path = "C:/Users/root/Desktop/new/char/9/";
			file_name = "C:/Users/root/Desktop/new/char/9/9.txt";
		}
		if (i == 10)
		{
			file_path = "C:/Users/root/Desktop/new/char/A/";
			file_name = "C:/Users/root/Desktop/new/char/A/A.txt";
		}
		if (i == 11)
		{
			file_path = "C:/Users/root/Desktop/new/char/B/";
			file_name = "C:/Users/root/Desktop/new/char/B/B.txt";
			cout << "11" << endl;
		}
		if (i == 12)
		{
			file_path = "C:/Users/root/Desktop/new/char/C/";
			file_name = "C:/Users/root/Desktop/new/char/C/C.txt";
			cout << "12" << endl;
		}
		ifstream fin(file_name);
		while (getline(fin,imgname))
		{
			imgname = file_path + imgname;
			src = imread(imgname);
			Mat f10 = charFeatures(src, 10);
			trainingData.push_back(f10);
			trainingLabels.push_back(i);
			cout << "loading--" << endl;
		}
		file_name = "";
		cout << "continue-" << endl;
	}
	cout << "��ɱ�ǩ" << endl;
	trainingData.convertTo(trainingData,CV_32FC1);
	cv::Mat train_classes =cv::Mat::zeros((int)trainingLabels.size(), 13, CV_32F);//

	for (int i = 0; i < train_classes.rows; ++i) {
		train_classes.at<float>(i, trainingLabels[i]) = 1.f;
	}
	Mat layers;
	int input_number = 120;
	int hidden_number = 40;
	int output_number = 13;//

	int N = input_number;
	int m = output_number;
	int first_hidden_neurons = int(std::sqrt((m + 2) * N) + 2 * std::sqrt(N / (m + 2)));
	int second_hidden_neurons = int(m * std::sqrt(N / (m + 2)));

	layers.create(1, 3, CV_32SC1);
	layers.at<int>(0) = input_number;
	layers.at<int>(1) = hidden_number;
	layers.at<int>(2) = output_number;

	Ptr<cv::ml::ANN_MLP> ann_;
	ann_->setLayerSizes(layers);
	ann_->setActivationFunction(cv::ml::ANN_MLP::SIGMOID_SYM, 1, 1);
	ann_->setTrainMethod(cv::ml::ANN_MLP::TrainingMethods::BACKPROP);
	ann_->setTermCriteria(cvTermCriteria(CV_TERMCRIT_ITER, 2000, 0.0001));
	ann_->setBackpropWeightScale(0.1);
	ann_->setBackpropMomentumScale(0.1);
	Ptr<cv::ml::TrainData >traindata =TrainData::create(trainingData, cv::ml::SampleTypes::ROW_SAMPLE,train_classes);
	ann_->train(traindata);
	ann_->save("C:/Users/root/Desktop/chinaOCR/trainOCR/ann.xml");

}